"""Support for PPA Contatto switches."""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from homeassistant.components.switch import SwitchEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity import DeviceInfo, EntityCategory
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .api import PPAContattoAPI
from .const import DEVICE_TYPE_GATE, DEVICE_TYPE_RELAY, DOMAIN

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up the PPA Contatto switch platform."""

    coordinator = hass.data[DOMAIN][config_entry.entry_id]["coordinator"]
    api = hass.data[DOMAIN][config_entry.entry_id]["api"]

    entities = []

    # Create control switches for each device
    for device in coordinator.data.get("devices", []):
        serial = device.get("serial")
        if not serial:
            continue

        # Add gate switch if it's shown
        if device.get("name", {}).get("gate", {}).get("show", False):
            entities.append(
                PPAContattoSwitch(
                    coordinator,
                    api,
                    device,
                    DEVICE_TYPE_GATE,
                    f"{serial}_gate",
                    device.get("name", {}).get("gate", {}).get("name", "Gate"),
                )
            )

        # Add relay switch if it's shown
        if device.get("name", {}).get("relay", {}).get("show", False):
            entities.append(
                PPAContattoSwitch(
                    coordinator,
                    api,
                    device,
                    DEVICE_TYPE_RELAY,
                    f"{serial}_relay",
                    device.get("name", {}).get("relay", {}).get("name", "Relay"),
                )
            )

    async_add_entities(entities)

    # Also add configuration switches
    from .config_entities import async_setup_config_switches
    await async_setup_config_switches(hass, config_entry, async_add_entities)


class PPAContattoSwitch(CoordinatorEntity, SwitchEntity):
    """Representation of a PPA Contatto switch."""

    def __init__(
        self,
        coordinator,
        api: PPAContattoAPI,
        device: Dict[str, Any],
        device_type: str,
        unique_id: str,
        name: str,
    ) -> None:
        """Initialize the switch."""
        super().__init__(coordinator)
        self._api = api
        self._device = device
        self._device_type = device_type
        self._attr_unique_id = unique_id
        self._attr_name = name
        self._serial = device.get("serial")

        # Set device info
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, self._serial)},
            name=f"PPA Contatto {self._serial}",
            manufacturer="PPA Contatto",
            model="Gate Controller",
            sw_version=device.get("version"),
            serial_number=self._serial,
            configuration_url="https://play-lh.googleusercontent.com/qDtSOerKV_rVZ2ZMi_-pFe7jccoGVH0aHDbykUAQeE15_UoWa0Ej1dKt3FfaQCh1PoI=w480-h960-rw",
        )

        # Initialize relay-specific attributes for all entities to avoid AttributeError
        self._relay_duration: Optional[int] = None
        self._momentary_active: bool = False
        self._momentary_task: Optional[asyncio.Task] = None

        # Set entity description based on device type
        if self._device_type == DEVICE_TYPE_RELAY:
            self._attr_entity_registry_enabled_default = True

    @property
    def is_on(self) -> bool:
        """Return true if the switch is on."""
        device = self._get_device_data()
        if not device:
            return False

        # Try to get status from latest reports first (more accurate)
        latest_status = device.get("latest_status", {})

        if self._device_type == DEVICE_TYPE_GATE:
            # Gates can stay open for extended periods
            # Check latest status first, then fall back to device status
            latest_gate_status = latest_status.get("gate")
            if latest_gate_status is not None:
                return latest_gate_status == "open"
            # Fallback to device status
            return device.get("status", {}).get("gate") == "open"

        elif self._device_type == DEVICE_TYPE_RELAY:
            # For relays, behavior depends on duration setting
            if self._relay_duration == -1:
                # Toggle switch mode - use actual relay state
                latest_relay_status = latest_status.get("relay")
                if latest_relay_status is not None:
                    return latest_relay_status == "on"
                return device.get("status", {}).get("relay") == "on"
            else:
                # Momentary button mode - show our momentary state
                return self._momentary_active

        return False

    @property
    def available(self) -> bool:
        """Return if entity is available."""
        device = self._get_device_data()
        if not device:
            return False
        return device.get("online", False) and device.get("authorized", False)

    @property
    def icon(self) -> str:
        """Return the icon to use in the frontend."""
        if self._device_type == DEVICE_TYPE_GATE:
            return "mdi:gate" if self.is_on else "mdi:gate-and"
        else:  # relay - icon depends on duration mode
            if self._relay_duration == -1:
                # Toggle switch mode
                return "mdi:electric-switch" if self.is_on else "mdi:electric-switch-closed"
            else:
                # Momentary button mode
                return "mdi:gesture-tap-button" if self.is_on else "mdi:radiobox-blank"

    def _get_device_data(self) -> Optional[Dict[str, Any]]:
        """Get current device data from coordinator."""
        devices = self.coordinator.data.get("devices", [])
        for device in devices:
            if device.get("serial") == self._serial:
                return device
        return None

    async def async_update(self) -> None:
        """Update relay duration for relays."""
        if self._device_type == DEVICE_TYPE_RELAY:
            self._relay_duration = await self._get_relay_duration()

    async def async_turn_on(self, **kwargs: Any) -> None:
        """Turn the switch on."""
        try:
            # For momentary relays, implement button behavior
            if self._device_type == DEVICE_TYPE_RELAY and self._relay_duration != -1:
                await self._activate_momentary_relay()
            else:
                # Normal switch behavior for gates and toggle relays
                await self._api.control_device(self._serial, self._device_type)
                _LOGGER.debug("Successfully activated %s %s", self._device_type, self._serial)

                # Schedule a delayed refresh to allow device status to update
                if hasattr(self.coordinator, "async_request_refresh_with_delay"):
                    asyncio.create_task(self.coordinator.async_request_refresh_with_delay(1.5))
                else:
                    await self.coordinator.async_request_refresh()

        except Exception as err:
            _LOGGER.error("Failed to turn on %s %s: %s", self._device_type, self._serial, err)
            raise

    async def _activate_momentary_relay(self) -> None:
        """Activate relay in momentary button mode."""
        # Cancel any existing momentary task
        if self._momentary_task and not self._momentary_task.done():
            self._momentary_task.cancel()

        # Immediately show button as "on"
        self._momentary_active = True
        self.async_write_ha_state()

        try:
            # Send the activation request
            await self._api.control_device(self._serial, self._device_type)
            _LOGGER.debug("Successfully activated momentary relay %s", self._serial)

            # Create task to reset button after duration
            duration_seconds = (self._relay_duration or 1000) / 1000.0  # Convert ms to seconds
            self._momentary_task = asyncio.create_task(self._reset_momentary_button(duration_seconds))

        except Exception as err:
            # If API call failed, immediately reset button
            self._momentary_active = False
            self.async_write_ha_state()
            raise

    async def _reset_momentary_button(self, duration_seconds: float) -> None:
        """Reset momentary button after duration."""
        try:
            # Wait for the relay duration
            await asyncio.sleep(duration_seconds)
            
            # Set button back to "off"
            self._momentary_active = False
            self.async_write_ha_state()
            
            # Pull fresh state from API to check actual relay status
            await self.coordinator.async_request_refresh()
            
        except asyncio.CancelledError:
            # Task was cancelled, still reset the button
            self._momentary_active = False
            self.async_write_ha_state()
        except Exception as err:
            _LOGGER.error("Error in momentary button reset for %s: %s", self._serial, err)
            self._momentary_active = False
            self.async_write_ha_state()

    async def async_turn_off(self, **kwargs: Any) -> None:
        """Turn the switch off."""
        if self._device_type == DEVICE_TYPE_RELAY and self._relay_duration == -1:
            # Toggle relay in switch mode - turning "off" should actually turn it off
            try:
                await self._api.control_device(self._serial, self._device_type)
                _LOGGER.debug("Successfully deactivated toggle relay %s", self._serial)
                
                if hasattr(self.coordinator, "async_request_refresh_with_delay"):
                    asyncio.create_task(self.coordinator.async_request_refresh_with_delay(1.5))
                else:
                    await self.coordinator.async_request_refresh()
            except Exception as err:
                _LOGGER.error("Failed to turn off %s %s: %s", self._device_type, self._serial, err)
                raise
        else:
            # For gates and momentary relays, turning "off" is the same as turning "on"
            # (it's a momentary action - like pressing a button)
            await self.async_turn_on(**kwargs)

    async def _get_relay_duration(self) -> Optional[int]:
        """Get the current relay duration setting."""
        if self._device_type != DEVICE_TYPE_RELAY:
            return None
            
        try:
            config = await self._api.get_device_configuration(self._serial)
            return config.get("config", {}).get("relayDuration", 1000)  # Default to 1000ms
        except Exception as err:
            _LOGGER.debug("Failed to get relay duration for %s: %s", self._serial, err)
            return 1000  # Default to momentary behavior

    @property
    def extra_state_attributes(self) -> Dict[str, Any]:
        """Return device specific state attributes."""
        device = self._get_device_data()
        if not device:
            return {}

        attrs = {
            "device_id": device.get("deviceId"),
            "mac_address": device.get("macAddress"),
            "version": device.get("version"),
            "role": device.get("role"),
            "favorite": device.get("favorite", False),
        }

        # Add status info from device
        status = device.get("status", {})
        if self._device_type == DEVICE_TYPE_GATE:
            attrs["gate_status"] = status.get("gate")
        else:
            attrs["relay_status"] = status.get("relay")

        # Add enhanced status from reports
        latest_status = device.get("latest_status", {})
        if latest_status.get("last_action"):
            attrs["last_action"] = latest_status["last_action"]
        if latest_status.get("last_user"):
            attrs["last_user"] = latest_status["last_user"]

        # Add latest status for comparison
        if self._device_type == DEVICE_TYPE_GATE and latest_status.get("gate"):
            attrs["latest_gate_status"] = latest_status["gate"]
        elif self._device_type == DEVICE_TYPE_RELAY:
            if latest_status.get("relay"):
                attrs["latest_relay_status"] = latest_status["relay"]
            
            # Add relay behavior info based on duration setting
            if self._relay_duration is not None:
                attrs["relay_duration_ms"] = self._relay_duration
                if self._relay_duration == -1:
                    attrs["behavior"] = "toggle_switch"
                    attrs["mode"] = "on_off_switch" 
                    attrs["note"] = "Relay acts as toggle switch - stays on/off when activated"
                else:
                    attrs["behavior"] = "momentary_button"
                    attrs["mode"] = "momentary"
                    attrs["note"] = f"Relay acts as momentary button - {self._relay_duration}ms pulse when activated"
            else:
                attrs["behavior"] = "unknown"
                attrs["note"] = "Configure relay duration in device settings"

        return attrs

    async def async_will_remove_from_hass(self) -> None:
        """Clean up when entity is removed."""
        if self._momentary_task and not self._momentary_task.done():
            self._momentary_task.cancel()
            try:
                await self._momentary_task
            except asyncio.CancelledError:
                pass
